import pandas as pd
import matplotlib.pyplot as plt


def sales_bar():
    """
    This function will create the graphical visualization for sales in each month
    :return: Bar graphs to represent monthly trends of sales
    """
    df = pd.read_csv('sales.csv')
    df.plot(kind='bar', x='month', y='sales', figsize=(10, 5))
    plt.xlabel('Month')
    plt.ylabel('Sales')
    plt.title('Sales Over Months')
    plt.savefig('sales.png', facecolor='white')
    plt.show()


def exp_bar():
    """
    This function will create the graphical visualization for expenditure in each month
    :return: Bar graphs to represent monthly trends of expenditure
    """
    df = pd.read_csv('sales.csv')
    df.plot(kind='bar', x='month', y='expenditure', figsize=(10, 5))
    plt.xlabel('Month')
    plt.ylabel('Expenditure')
    plt.title('Expenditure Over Months')
    plt.legend(loc='upper right')
    plt.savefig('expenditure.png', facecolor='white')
    plt.show()
