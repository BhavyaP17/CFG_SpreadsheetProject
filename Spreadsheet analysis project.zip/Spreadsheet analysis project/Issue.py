import pandas as pd

df = pd.read_csv('sales.csv')

# Calculate the percentage changes in the sales
df['Sales_percentage_change'] = round(df['sales'].pct_change() * 100, 2)

# Display the DataFrame
print(df)

# Drop the rows with NaN values using df = df.dropna() to make the dataframe with percentage change meaningful
