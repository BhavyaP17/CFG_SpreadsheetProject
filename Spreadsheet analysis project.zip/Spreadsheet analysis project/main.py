# Spreadsheet Analysis Project

import requirements as req
import extend as e


def main():
    print("'Welcome to the spreadsheet analysis project'")

    user = input("Choose whether you want to analyze the sales, expenditure or both: ")
    print('\n')

    if user == 'sales':
        req.sales_sum()
        print('\n')

    elif user == 'expenditure':
        req.expenditure_sum()
        print('\n')

    elif user == 'both':
        req.sales_sum()
        req.expenditure_sum()

    else:
        exit()


if __name__ == '__main__':
    main()
    user = input('choose whether to continue with data analysis report of sales (y/n):')
    if user == 'y':
        e.data_analysis()
        print('Thank you for analysing the sales spreadsheet report. Bye. ')
    else:
        print('Thank you. Bye. ')
        exit()
