import csv


def read_data():
    """
    Read the data from the file sales.csv
    :return: This function will return the data from the file.
    """
    data = []

    with open('sales.csv', 'r') as sales_csv:
        spreadsheet = csv.DictReader(sales_csv)
        for row in spreadsheet:
            data.append(row)

    return data


def sales_sum():
    """
    Read the file and get the data using the read_data() function. Initiate the sales list variable and append the
    sales value from the data to form the sales list. Find the total sum of the sales and print out the results.
    Calculate the percentage change of sales in each month and print out the values
    :return: print out the sum and percentage change of sales for each month.
    """
    data = read_data()
    sales = []
    percentage_changes = []

    # Total sales of each month
    print('Total sales of each month are listed below:')
    for i, row in enumerate(data, start=1):
        sale = int(row['sales'])
        sales.append(sale)
        total = sum(sales)
        print(f'Total sales in {i} months : {total}')
    print('\n')

    # Percentage change of sales in each month
    print('Percentage change of sales in each month are listed below:')
    for i in range(len(sales)):
        if i != len(sales)-1:
            curr_value = sales[i]
            next_value = sales[i+1]
            perc_change = round(((next_value - curr_value) / curr_value) * 100, 2)
            percentage_changes.append(perc_change)
            print(f'The percentage change of sales in between current month {curr_value} and next month '
                  f'{next_value} is {perc_change}% ')
    print('\n')


def expenditure_sum():
    """
    Read the file and get the data using the read_data() function. Initiate the expenditure list variable and
    append the expenditure value from the data to form the expenditure list.
    Find the total sum of the expenditure and print out the results.
    :return: print out the sum of expenditure for each month.
    """
    data = read_data()
    expenditures = []

    # Total expenditure of each month
    print('Total expenditure of each month are listed below:')
    for i, row in enumerate(data, start=1):
        expenditure = int(row['expenditure'])
        expenditures.append(expenditure)
        total = sum(expenditures)
        print(f'Total expenditure in {i} months : {total}')
    print('\n')
