import pandas as pd
import matplotlib.pyplot as plt
import numpy as np

# Sales Bar chart
x = np.array(['jan', 'feb', 'mar', 'apr', 'may', 'jun', 'jul', 'aug', 'sep', 'oct', 'nov', 'dec'])
y = np.array([6626, 1521, 1842, 2051, 1728, 2138, 7479, 4434, 3615, 5472, 7224, 1812])

plt.bar(x, y)
plt.show()

# Expenditure Bar Chart
x = np.array(['jan', 'feb', 'mar', 'apr', 'may', 'jun', 'jul', 'aug', 'sep', 'oct', 'nov', 'dec'])
y = np.array([3808, 3373, 3965, 1098, 3046, 2258, 2084, 2799, 1649, 1116, 1431, 3532])

plt.bar(x,y, color = 'orange')
plt.show()

# Sales and Expenditure Bar chart
months = ('jan', 'feb', 'mar', 'apr', 'may', 'jun', 'jul', 'aug', 'sep', 'oct', 'nov', 'dec')
sales_exp_dict = {
    'Sales': (6626, 1521, 1842, 2051, 1728, 2138, 7479, 4434, 3615, 5472, 7224, 1812),
    'Expenditure': (3808, 3373, 3965, 1098, 3046, 2258, 2084, 2799, 1649, 1116, 1431, 3532),

}
x = np.arange(len(months))  # the label locations
width = 0.5  # the width of the bars
multiplier = 0
fig, ax = plt.subplots(layout='constrained')
for attribute, measurement in sales_exp_dict.items():
    offset = width * multiplier
    rects = ax.bar(x + offset, measurement, width, label=attribute)
    ax.bar_label(rects, padding=2)
    multiplier += 1
# Add some text for labels, title and custom x-axis tick labels, etc.
ax.set_ylabel('Cost (££)')
ax.set_title('Sales and Expenditure by month')
ax.set_xticks(x + width, months)
ax.legend(loc='upper left', ncols=2)
ax.set_ylim(0, 10000)
plt.show()

# Net profit bar chart
data = {'Month': ['jan', 'feb', 'mar', 'apr', 'may', 'jun', 'jul', 'aug', 'sep', 'oct', 'nov', 'dec'],
        'sales': (6626, 1521, 1842, 2051, 1728, 2138, 7479, 4434, 3615, 5472, 7224, 1812),
        'expenditure': (3808, 3373, 3965, 1098, 3046, 2258, 2084, 2799, 1649, 1116, 1431, 3532)}
df = pd.DataFrame(data)
# Calculate net profit for each month
df['Net Profit'] = df['sales'] - df['expenditure']
# Determine profit or loss and color the bars accordingly
df['Profit or Loss'] = ['sales' if x >= 0 else 'Loss' for x in df['Net Profit']]
colors = df['Profit or Loss'].map({'Profit': 'green', 'Loss': 'red'})
# Determine colors based on net profit or loss
colors = ['green' if profit >= 0 else 'red' for profit in df['Net Profit']]
# Create a plot
plt.figure(figsize=(8, 5))
plt.bar(df['Month'], df['Net Profit'], color=colors)
# Add labels and a title
plt.xlabel('Month')
plt.ylabel('Net Profit/Loss')
plt.title('Monthly Net Profit/Loss')
# Show the plot
plt.grid(True)
plt.show()

# Average Bar chart
sales = [6626, 1521, 1842, 2051,1728, 2138, 7479, 4434, 3615, 5472, 7224, 1812]
expenditure = [3808, 3373, 3965, 1098, 3046, 2258, 2084, 2799, 1649, 1116, 1431, 3532]
# Calculating the mean using numpy
average_sales = np.mean(sales)
average_expenditure = np.mean(expenditure)
print(f"Average sales: {average_sales}")
print(f"Average Expenditure: {average_expenditure}")
# Create a bar graph
categories = ['sales', 'expenditure']
values = [average_sales, average_expenditure]
plt.bar(categories, values, color=['blue', 'pink'])
plt.xlabel
plt.ylabel('units ££')
plt.title('Average sales and expenditures')
plt.show()
