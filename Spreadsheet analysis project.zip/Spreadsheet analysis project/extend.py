import pandas as pd
import matplotlib.pyplot as plt
import visuals as v


def data_analysis():
    df = pd.read_csv('sales.csv')

    # Calculate Net Profit and Net Profit Percentage
    # net_profit = df.sales - df.expenditure
    df['Net_profit'] = df.apply(lambda row: row['sales'] - row['expenditure'], axis=1)

    # Net_profit_percentage = (df.Net_profit/df.sales)*100 - error handling to avoid the division by zero
    df['Net_profit_percentage'] = df.apply(lambda row: (row['Net_profit'] / row['sales']) * 100 if row['sales'] != 0 else 0, axis=1)
    # Format columns with 2 decimal places
    df['Net_profit_percentage'] = df['Net_profit_percentage'].apply(lambda x: '{:.2f}'.format(x))
    df['Net_profit_percentage'] = pd.to_numeric(df['Net_profit_percentage'], errors='coerce')

    # Display the formatted DataFrame
    print(df)
    print('\n')

    # Identify the month with highest and lowest sales of the year 2018
    print('Identify the month with highest sales in the year 2018:')
    print(df[df.sales == df.sales.max()])
    print('\n')

    print('Identify the month with lowest sales in the year 2018:')
    print(df[df.sales == df.sales.min()])
    print('\n')

    # Bar graph to represent monthly trends of sales
    print("Visuals are displayed in the figures as Bar graph to represent monthly trends of sales.")
    v.sales_bar()
    print('\n')

    # Identify the month with highest and lowest expenditure of the year 2018
    print('Identify the month with highest expenditure in the year 2018:')
    print(df[df.expenditure == df.expenditure.max()])
    print('\n')

    print('Identify the month with lowest expenditure in the year 2018:')
    print(df[df.expenditure == df.expenditure.min()])
    print('\n')

    # Bar graph to represent monthly trends of expenditure
    print("Visuals are displayed in the figures as Bar graph to represent monthly trends of expenditure.")
    v.exp_bar()
    print('\n')

    # Identify the month with highest and lowest profit of the year 2018
    print('Identify the month with highest profit in the year 2018:')
    print(df[df.Net_profit_percentage == df.Net_profit_percentage.max()])
    print('\n')

    print('Identify the month with lowest profit in the year 2018:')
    print(df[df.Net_profit_percentage == df.Net_profit_percentage.min()])
    print('\n')

    # Line graph to represent monthly trends of Net Profit %
    print("Visuals are displayed in the figures as Bar graph to represent monthly trends of Net Profit %.")
    df.plot(kind='line', x='month', y='Net_profit_percentage', figsize=(10, 5))
    plt.xlabel('Month')
    plt.ylabel('Net Profit Percentage')
    plt.title('Net Profit Percentage Over Months')
    plt.savefig('NetProfit.png', facecolor='white')
    plt.show()
    print('\n')

    # Determine profit or loss in the Net Profit and color the bars accordingly to display
    df['Profit or Loss'] = ['Profit' if x >= 0 else 'Loss' for x in df['Net_profit']]
    colors = df['Profit or Loss'].map({'Profit': 'green', 'Loss': 'red'})
    # Determine colors based on net profit or loss
    colors = ['green' if profit >= 0 else 'red' for profit in df['Net_profit']]
    # Create a plot
    plt.figure(figsize=(8, 5))
    plt.bar(df['month'], df['Net_profit'], color=colors)
    # Add labels and a title
    plt.xlabel('Month')
    plt.ylabel('Net Profit/Loss')
    plt.title('Monthly Net Profit/Loss')
    # Show the plot
    plt.grid(True)
    plt.savefig('Net Profit_Loss.png', facecolor='white')
    plt.show()

    # statistics of sales
    print('Statistics of sales values:')
    print(df.describe()['sales'])
    print('\n')

    # statistics of expenditure
    print('Statistics of expenditure values:')
    print(df.describe()['expenditure'])
    print('\n')

    # Write the dataframe into the file 'Sales_Analysis.csv'
    df.to_csv('Sales_Analysis.csv', index=False)
    print("'Sales_Analysis.csv' file is created with the sales analysis data.")
    print('\n')
